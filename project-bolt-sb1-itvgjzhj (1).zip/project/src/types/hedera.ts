export interface HederaAccount {
  accountId: string;
  publicKey: string;
  network: string;
}

export interface WalletData {
  accountIds: string[];
  topic: string;
  network: string;
}

export interface TransactionResult {
  transactionId: string;
  status: string;
  receipt?: any;
}

export interface TopicInfo {
  topicId: string;
  memo: string;
  submitKey?: string;
}

export interface TokenInfo {
  tokenId: string;
  name: string;
  symbol: string;
  decimals: number;
  totalSupply: string;
}

export interface NFTInfo {
  tokenId: string;
  serialNumber: string;
  metadata: string;
  accountId: string;
}

export interface ContractInfo {
  contractId: string;
  bytecode: string;
  gas: number;
}

export interface ScheduledTransaction {
  scheduleId: string;
  payerAccountId: string;
  adminKey?: string;
  memo?: string;
}