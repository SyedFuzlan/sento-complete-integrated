import { useState, useEffect } from 'react';
import { HashConnect } from '@hashgraph/hashconnect';
import { WalletData, HederaAccount } from '../types/hedera';
import toast from 'react-hot-toast';

export const useHashConnect = () => {
  const [hashConnect, setHashConnect] = useState<HashConnect | null>(null);
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [accountId, setAccountId] = useState<string>('');

  const initHashConnect = async () => {
    try {
      const hashConnectInstance = new HashConnect();
      
      const appMetadata = {
        name: "Sento DApp",
        description: "AI-driven DeFi guard",
        icon: "https://wallet.hashpack.app/assets/favicon/favicon.ico",
      };

      // 1. Initialize HashConnect
      const initData = await hashConnectInstance.init(appMetadata, "testnet", false);
      
      // 2. Connect to HashConnect
      const state = await hashConnectInstance.connect();
      
      // 3. Check if there's a saved pairing
      if (state.savedPairings && state.savedPairings.length > 0) {
        const savedPairing = state.savedPairings[0];
        setWalletData(savedPairing);
        setIsConnected(true);
        setAccountId(savedPairing.accountIds[0]);
      }

      // 4. Listen for pairing event from HASHCONNECT instance (not state)
      hashConnectInstance.pairingEvent.once((pairingData) => {
        console.log("✅ Connected with:", pairingData.accountIds[0]);
        setWalletData(pairingData);
        setIsConnected(true);
        setAccountId(pairingData.accountIds[0]);
        toast.success('Wallet connected successfully!');
      });

      // 5. Listen for disconnection event
      hashConnectInstance.disconnectionEvent.once(() => {
        setWalletData(null);
        setIsConnected(false);
        setAccountId('');
        toast.success('Wallet disconnected');
      });

      // 6. Listen for connection status changes
      hashConnectInstance.connectionStatusChangeEvent.on((connectionStatus) => {
        console.log('Connection status changed:', connectionStatus);
      });

      setHashConnect(hashConnectInstance);
    } catch (error) {
      console.error('Failed to initialize HashConnect:', error);
      toast.error('Failed to initialize wallet connection');
    }
  };

  const connectToWallet = async () => {
    if (hashConnect) {
      try {
        // Generate pairing string and connect
        const state = await hashConnect.connect();
        const pairingString = hashConnect.generatePairingString(state, "testnet", false);
        
        // Try to find local wallets and connect
        hashConnect.findLocalWallets();
        hashConnect.connectToLocalWallet(pairingString);
        
        // If no local wallet found, open request modal
        await hashConnect.openRequestModal();
      } catch (error) {
        console.error('Failed to connect to wallet:', error);
        toast.error('Failed to connect to wallet');
      }
    }
  };

  const disconnectWallet = () => {
    if (hashConnect) {
      hashConnect.disconnect();
    }
  };

  const sendTransaction = async (transaction: any) => {
    if (!hashConnect || !walletData) {
      throw new Error('Wallet not connected');
    }

    try {
      const result = await hashConnect.sendTransaction(walletData.topic, transaction);
      return result;
    } catch (error) {
      console.error('Transaction failed:', error);
      throw error;
    }
  };

  useEffect(() => {
    initHashConnect();
  }, []);

  return {
    hashConnect,
    walletData,
    isConnected,
    accountId,
    connectToWallet,
    disconnectWallet,
    sendTransaction
  };
};