import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Wallet, 
  MessageCircle, 
  Coins, 
  FileText, 
  Image, 
  Calendar, 
  User,
  Network
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const navItems = [
    { path: '/', label: 'Dashboard', icon: Home },
    { path: '/wallet', label: 'Wallet', icon: Wallet },
    { path: '/hcs', label: 'HCS', icon: MessageCircle },
    { path: '/hts', label: 'HTS', icon: Coins },
    { path: '/hscs', label: 'HSCS', icon: FileText },
    { path: '/nft', label: 'NFTs', icon: Image },
    { path: '/scheduled', label: 'Scheduled Txns', icon: Calendar },
    { path: '/account', label: 'Account Ops', icon: User },
  ];

  return (
    <div className="w-64 h-screen bg-black border-r border-gray-800 flex flex-col">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center space-x-2">
          <Network className="w-8 h-8 text-white" />
          <span className="text-xl font-bold text-white font-mono">Sento</span>
        </div>
      </div>
      
      <nav className="flex-1 pt-6">
        <div className="space-y-2 px-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    isActive
                      ? 'bg-gray-800 text-white'
                      : 'text-gray-400 hover:bg-gray-900 hover:text-white'
                  }`
                }
              >
                <Icon className="w-5 h-5" />
                <span className="font-mono text-sm">{item.label}</span>
              </NavLink>
            );
          })}
        </div>
      </nav>
      
      <div className="p-4 border-t border-gray-800">
        <div className="text-xs text-gray-500 font-mono">
          Testnet Environment
        </div>
      </div>
    </div>
  );
};

export default Sidebar;