import React from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { Network, Wallet, LogOut } from 'lucide-react';

const Topbar: React.FC = () => {
  const { isConnected, accountId, connectToWallet, disconnectWallet } = useHashConnect();

  return (
    <div className="h-16 bg-gray-900 border-b border-gray-800 flex items-center justify-between px-6">
      <div className="flex items-center space-x-4">
        <div className="text-white font-mono text-lg">Sento DApp</div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Network className="w-4 h-4" />
          <span className="text-sm font-mono">Testnet</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        {isConnected ? (
          <>
            <div className="flex items-center space-x-2 bg-gray-800 px-4 py-2 rounded-xl">
              <Wallet className="w-4 h-4 text-green-400" />
              <span className="text-sm font-mono text-white">
                {accountId.slice(0, 8)}...{accountId.slice(-4)}
              </span>
            </div>
            <button
              onClick={disconnectWallet}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-xl transition-colors"
            >
              <LogOut className="w-4 h-4 text-white" />
              <span className="text-sm font-mono text-white">Disconnect</span>
            </button>
          </>
        ) : (
          <button
            onClick={connectToWallet}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors"
          >
            <Wallet className="w-4 h-4 text-white" />
            <span className="text-sm font-mono text-white">Connect Wallet</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default Topbar;