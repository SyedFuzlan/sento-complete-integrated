import React, { useState } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { accountApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import { User, Plus, Snowflake, Sun, Trash2, Eye, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

const AccountPage: React.FC = () => {
  const { isConnected } = useHashConnect();
  const [loading, setLoading] = useState(false);
  const [accounts, setAccounts] = useState<any[]>([]);
  
  // Create Account Form
  const [newAccountBalance, setNewAccountBalance] = useState('10');
  
  // Account Operations Form
  const [operationAccountId, setOperationAccountId] = useState('');
  const [operationTokenId, setOperationTokenId] = useState('');
  const [wipeAmount, setWipeAmount] = useState('');
  
  // View Account Form
  const [viewAccountId, setViewAccountId] = useState('');
  const [accountInfo, setAccountInfo] = useState<any>(null);
  const [accountBalance, setAccountBalance] = useState<any>(null);

  const createAccount = async () => {
    if (!newAccountBalance || parseFloat(newAccountBalance) <= 0) {
      toast.error('Valid initial balance is required');
      return;
    }

    setLoading(true);
    try {
      const result = await accountApi.createAccount(newAccountBalance);
      toast.success(`Account created: ${result.accountId}`);
      setNewAccountBalance('10');
      
      // Add to local accounts list
      setAccounts(prev => [...prev, result]);
    } catch (error) {
      console.error('Failed to create account:', error);
      toast.error('Failed to create account');
    } finally {
      setLoading(false);
    }
  };

  const freezeAccount = async () => {
    if (!operationAccountId || !operationTokenId) {
      toast.error('Account ID and Token ID are required');
      return;
    }

    setLoading(true);
    try {
      const result = await accountApi.freezeAccount(operationAccountId, operationTokenId);
      toast.success(`Account frozen: ${result.transactionId}`);
    } catch (error) {
      console.error('Failed to freeze account:', error);
      toast.error('Failed to freeze account');
    } finally {
      setLoading(false);
    }
  };

  const unfreezeAccount = async () => {
    if (!operationAccountId || !operationTokenId) {
      toast.error('Account ID and Token ID are required');
      return;
    }

    setLoading(true);
    try {
      const result = await accountApi.unfreezeAccount(operationAccountId, operationTokenId);
      toast.success(`Account unfrozen: ${result.transactionId}`);
    } catch (error) {
      console.error('Failed to unfreeze account:', error);
      toast.error('Failed to unfreeze account');
    } finally {
      setLoading(false);
    }
  };

  const wipeAccount = async () => {
    if (!operationAccountId || !operationTokenId || !wipeAmount) {
      toast.error('Account ID, Token ID, and amount are required');
      return;
    }

    setLoading(true);
    try {
      const result = await accountApi.wipeAccount(operationAccountId, operationTokenId, wipeAmount);
      toast.success(`Account wiped: ${result.transactionId}`);
      setWipeAmount('');
    } catch (error) {
      console.error('Failed to wipe account:', error);
      toast.error('Failed to wipe account');
    } finally {
      setLoading(false);
    }
  };

  const viewAccount = async () => {
    if (!viewAccountId.trim()) {
      toast.error('Account ID is required');
      return;
    }

    setLoading(true);
    try {
      const [infoResult, balanceResult] = await Promise.all([
        accountApi.getAccountInfo(viewAccountId),
        accountApi.getAccountBalance(viewAccountId)
      ]);
      
      setAccountInfo(infoResult);
      setAccountBalance(balanceResult);
    } catch (error) {
      console.error('Failed to fetch account info:', error);
      toast.error('Failed to fetch account information');
    } finally {
      setLoading(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">Account Operations</h1>
        <Card className="text-center">
          <div className="py-8">
            <User className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Wallet Not Connected</h2>
            <p className="text-gray-400">
              Connect your wallet to perform account operations
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white font-mono">Account Operations</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Create Account */}
        <Card title="Create Account">
          <div className="space-y-4">
            <Input
              label="Initial Balance (ℏ)"
              type="number"
              value={newAccountBalance}
              onChange={(e) => setNewAccountBalance(e.target.value)}
              placeholder="10"
              required
            />
            <Button onClick={createAccount} disabled={loading}>
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Account'}
            </Button>
          </div>
        </Card>

        {/* Account Operations */}
        <Card title="Account Operations">
          <div className="space-y-4">
            <Input
              label="Account ID"
              value={operationAccountId}
              onChange={(e) => setOperationAccountId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <Input
              label="Token ID"
              value={operationTokenId}
              onChange={(e) => setOperationTokenId(e.target.value)}
              placeholder="0.0.67890"
              required
            />
            <div className="flex space-x-2">
              <Button onClick={freezeAccount} disabled={loading} variant="secondary" className="flex-1">
                <Snowflake className="w-4 h-4 mr-2" />
                Freeze
              </Button>
              <Button onClick={unfreezeAccount} disabled={loading} variant="primary" className="flex-1">
                <Sun className="w-4 h-4 mr-2" />
                Unfreeze
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Wipe Account */}
      <Card title="Wipe Account">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Account ID"
              value={operationAccountId}
              onChange={(e) => setOperationAccountId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <Input
              label="Token ID"
              value={operationTokenId}
              onChange={(e) => setOperationTokenId(e.target.value)}
              placeholder="0.0.67890"
              required
            />
            <Input
              label="Amount to Wipe"
              type="number"
              value={wipeAmount}
              onChange={(e) => setWipeAmount(e.target.value)}
              placeholder="100"
              required
            />
          </div>
          <Button onClick={wipeAccount} disabled={loading} variant="danger">
            <Trash2 className="w-4 h-4 mr-2" />
            {loading ? 'Wiping...' : 'Wipe Account'}
          </Button>
          <p className="text-yellow-400 text-sm">
            ⚠️ Warning: This action will permanently remove tokens from the account
          </p>
        </div>
      </Card>

      {/* View Account */}
      <Card title="View Account Information">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Account ID"
              value={viewAccountId}
              onChange={(e) => setViewAccountId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={viewAccount} disabled={loading}>
                <Eye className="w-4 h-4 mr-2" />
                {loading ? 'Loading...' : 'View Account'}
              </Button>
            </div>
          </div>

          {accountInfo && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-800 rounded-xl">
                <h3 className="font-bold text-white mb-2">Account Information</h3>
                <div className="space-y-2">
                  <p><span className="text-gray-400">Account ID:</span> <span className="text-white font-mono">{accountInfo.accountId}</span></p>
                  <p><span className="text-gray-400">Public Key:</span> <span className="text-white font-mono text-xs break-all">{accountInfo.publicKey || 'N/A'}</span></p>
                  <p><span className="text-gray-400">Created:</span> <span className="text-white">{accountInfo.createdAt ? new Date(accountInfo.createdAt).toLocaleString() : 'N/A'}</span></p>
                  <p><span className="text-gray-400">Deleted:</span> <span className="text-white">{accountInfo.deleted ? 'Yes' : 'No'}</span></p>
                </div>
              </div>

              {accountBalance && (
                <div className="p-4 bg-gray-800 rounded-xl">
                  <h3 className="font-bold text-white mb-2">Account Balance</h3>
                  <div className="space-y-2">
                    <p><span className="text-gray-400">HBAR Balance:</span> <span className="text-white font-mono">{accountBalance.balance} ℏ</span></p>
                    {accountBalance.tokens && accountBalance.tokens.length > 0 && (
                      <div>
                        <p className="text-gray-400">Token Balances:</p>
                        <div className="space-y-1 mt-1">
                          {accountBalance.tokens.map((token: any, index: number) => (
                            <p key={index} className="text-white font-mono text-sm">
                              {token.tokenId}: {token.balance}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* Recent Accounts */}
      {accounts.length > 0 && (
        <Card title="Recent Accounts">
          <div className="space-y-2">
            {accounts.map((account, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                <div>
                  <p className="text-white font-mono">{account.accountId}</p>
                  <p className="text-gray-400 text-sm">Balance: {account.balance} ℏ</p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="secondary"
                    onClick={() => setOperationAccountId(account.accountId)}
                  >
                    Use
                  </Button>
                  <Button
                    variant="primary"
                    onClick={() => setViewAccountId(account.accountId)}
                  >
                    View
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default AccountPage;