import React, { useState } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { scheduledApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import TextArea from '../components/TextArea';
import { Calendar, Plus, Play, Eye, PenTool } from 'lucide-react';
import toast from 'react-hot-toast';

const ScheduledPage: React.FC = () => {
  const { isConnected } = useHashConnect();
  const [loading, setLoading] = useState(false);
  const [scheduledTxns, setScheduledTxns] = useState<any[]>([]);
  
  // Create Scheduled Transaction Form
  const [payerAccountId, setPayerAccountId] = useState('');
  const [transactionBody, setTransactionBody] = useState('');
  const [memo, setMemo] = useState('');
  
  // Sign Scheduled Transaction Form
  const [signScheduleId, setSignScheduleId] = useState('');
  const [signature, setSignature] = useState('');
  
  // Execute Scheduled Transaction Form
  const [executeScheduleId, setExecuteScheduleId] = useState('');
  
  // View Scheduled Transaction Form
  const [viewScheduleId, setViewScheduleId] = useState('');
  const [scheduleInfo, setScheduleInfo] = useState<any>(null);

  const createScheduledTransaction = async () => {
    if (!payerAccountId || !transactionBody.trim()) {
      toast.error('Payer account ID and transaction body are required');
      return;
    }

    setLoading(true);
    try {
      let parsedTransactionBody;
      try {
        parsedTransactionBody = JSON.parse(transactionBody);
      } catch (error) {
        throw new Error('Invalid JSON in transaction body');
      }
      
      const result = await scheduledApi.createScheduledTransaction(
        payerAccountId,
        parsedTransactionBody,
        memo || undefined
      );
      
      toast.success(`Scheduled transaction created: ${result.scheduleId}`);
      setPayerAccountId('');
      setTransactionBody('');
      setMemo('');
      
      // Add to local scheduled transactions list
      setScheduledTxns(prev => [...prev, result]);
    } catch (error) {
      console.error('Failed to create scheduled transaction:', error);
      toast.error('Failed to create scheduled transaction');
    } finally {
      setLoading(false);
    }
  };

  const signScheduledTransaction = async () => {
    if (!signScheduleId || !signature.trim()) {
      toast.error('Schedule ID and signature are required');
      return;
    }

    setLoading(true);
    try {
      const result = await scheduledApi.signScheduledTransaction(signScheduleId, signature);
      toast.success(`Scheduled transaction signed: ${result.transactionId}`);
      setSignature('');
    } catch (error) {
      console.error('Failed to sign scheduled transaction:', error);
      toast.error('Failed to sign scheduled transaction');
    } finally {
      setLoading(false);
    }
  };

  const executeScheduledTransaction = async () => {
    if (!executeScheduleId.trim()) {
      toast.error('Schedule ID is required');
      return;
    }

    setLoading(true);
    try {
      const result = await scheduledApi.executeScheduledTransaction(executeScheduleId);
      toast.success(`Scheduled transaction executed: ${result.transactionId}`);
      setExecuteScheduleId('');
    } catch (error) {
      console.error('Failed to execute scheduled transaction:', error);
      toast.error('Failed to execute scheduled transaction');
    } finally {
      setLoading(false);
    }
  };

  const viewScheduledTransaction = async () => {
    if (!viewScheduleId.trim()) {
      toast.error('Schedule ID is required');
      return;
    }

    setLoading(true);
    try {
      const result = await scheduledApi.getScheduledTransactionInfo(viewScheduleId);
      setScheduleInfo(result);
    } catch (error) {
      console.error('Failed to fetch scheduled transaction info:', error);
      toast.error('Failed to fetch scheduled transaction information');
    } finally {
      setLoading(false);
    }
  };

  // Example transaction body for demonstration
  const exampleTransactionBody = `{
  "cryptoTransfer": {
    "transfers": [
      {
        "accountId": "0.0.12345",
        "amount": "-1000000000"
      },
      {
        "accountId": "0.0.67890",
        "amount": "1000000000"
      }
    ]
  }
}`;

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">Scheduled Transactions</h1>
        <Card className="text-center">
          <div className="py-8">
            <Calendar className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Wallet Not Connected</h2>
            <p className="text-gray-400">
              Connect your wallet to create and manage scheduled transactions
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white font-mono">Scheduled Transactions</h1>

      {/* Example Transaction Body */}
      <Card title="Example Transaction Body">
        <div className="space-y-4">
          <TextArea
            label="JSON Transaction Body Format"
            value={exampleTransactionBody}
            onChange={() => {}}
            rows={12}
            className="font-mono"
          />
          <p className="text-gray-400 text-sm">
            Use this format when creating scheduled transactions. The transaction will be executed when all required signatures are collected.
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Create Scheduled Transaction */}
        <Card title="Create Scheduled Transaction">
          <div className="space-y-4">
            <Input
              label="Payer Account ID"
              value={payerAccountId}
              onChange={(e) => setPayerAccountId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <TextArea
              label="Transaction Body (JSON)"
              value={transactionBody}
              onChange={(e) => setTransactionBody(e.target.value)}
              placeholder='{"cryptoTransfer": {...}}'
              rows={6}
              required
            />
            <Input
              label="Memo (Optional)"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              placeholder="Transaction memo"
            />
            <Button onClick={createScheduledTransaction} disabled={loading}>
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Scheduled Transaction'}
            </Button>
          </div>
        </Card>

        {/* Sign Scheduled Transaction */}
        <Card title="Sign Scheduled Transaction">
          <div className="space-y-4">
            <Input
              label="Schedule ID"
              value={signScheduleId}
              onChange={(e) => setSignScheduleId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <TextArea
              label="Signature"
              value={signature}
              onChange={(e) => setSignature(e.target.value)}
              placeholder="Enter signature hex"
              rows={4}
              required
            />
            <Button onClick={signScheduledTransaction} disabled={loading}>
              <PenTool className="w-4 h-4 mr-2" />
              {loading ? 'Signing...' : 'Sign Transaction'}
            </Button>
          </div>
        </Card>
      </div>

      {/* Execute Scheduled Transaction */}
      <Card title="Execute Scheduled Transaction">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Schedule ID"
              value={executeScheduleId}
              onChange={(e) => setExecuteScheduleId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={executeScheduledTransaction} disabled={loading}>
                <Play className="w-4 h-4 mr-2" />
                {loading ? 'Executing...' : 'Execute Transaction'}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* View Scheduled Transaction */}
      <Card title="View Scheduled Transaction">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Schedule ID"
              value={viewScheduleId}
              onChange={(e) => setViewScheduleId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={viewScheduledTransaction} disabled={loading}>
                <Eye className="w-4 h-4 mr-2" />
                {loading ? 'Loading...' : 'View Transaction'}
              </Button>
            </div>
          </div>

          {scheduleInfo && (
            <div className="p-4 bg-gray-800 rounded-xl">
              <h3 className="font-bold text-white mb-2">Scheduled Transaction Information</h3>
              <div className="space-y-2">
                <p><span className="text-gray-400">Schedule ID:</span> <span className="text-white font-mono">{scheduleInfo.scheduleId}</span></p>
                <p><span className="text-gray-400">Payer Account:</span> <span className="text-white font-mono">{scheduleInfo.payerAccountId}</span></p>
                <p><span className="text-gray-400">Status:</span> <span className="text-white">{scheduleInfo.status}</span></p>
                <p><span className="text-gray-400">Memo:</span> <span className="text-white">{scheduleInfo.memo || 'None'}</span></p>
                {scheduleInfo.adminKey && (
                  <p><span className="text-gray-400">Admin Key:</span> <span className="text-white font-mono">{scheduleInfo.adminKey}</span></p>
                )}
                {scheduleInfo.transactionBody && (
                  <div>
                    <p className="text-gray-400">Transaction Body:</p>
                    <pre className="text-white font-mono text-xs bg-gray-700 p-2 rounded mt-1 overflow-auto">
                      {JSON.stringify(scheduleInfo.transactionBody, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Recent Scheduled Transactions */}
      {scheduledTxns.length > 0 && (
        <Card title="Recent Scheduled Transactions">
          <div className="space-y-2">
            {scheduledTxns.map((txn, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                <div>
                  <p className="text-white font-mono">{txn.scheduleId}</p>
                  <p className="text-gray-400 text-sm">Payer: {txn.payerAccountId}</p>
                  <p className="text-gray-400 text-sm">{txn.memo || 'No memo'}</p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="secondary"
                    onClick={() => setSignScheduleId(txn.scheduleId)}
                  >
                    Sign
                  </Button>
                  <Button
                    variant="primary"
                    onClick={() => setExecuteScheduleId(txn.scheduleId)}
                  >
                    Execute
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default ScheduledPage;