import React, { useState, useEffect } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import Card from '../components/Card';
import { 
  MessageCircle, 
  Coins, 
  FileText, 
  Image, 
  Calendar, 
  User,
  TrendingUp,
  Activity,
  Network
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const { isConnected, accountId } = useHashConnect();
  const [stats, setStats] = useState({
    totalTransactions: 0,
    activeTokens: 0,
    nftsOwned: 0,
    scheduledTxns: 0
  });

  useEffect(() => {
    // Mock data for demonstration
    setStats({
      totalTransactions: 142,
      activeTokens: 8,
      nftsOwned: 23,
      scheduledTxns: 3
    });
  }, []);

  const services = [
    {
      name: 'HCS',
      description: 'Hedera Consensus Service',
      icon: MessageCircle,
      color: 'text-blue-400',
      bgColor: 'bg-blue-900/20'
    },
    {
      name: 'HTS',
      description: 'Hedera Token Service',
      icon: Coins,
      color: 'text-green-400',
      bgColor: 'bg-green-900/20'
    },
    {
      name: 'HSCS',
      description: 'Smart Contract Service',
      icon: FileText,
      color: 'text-purple-400',
      bgColor: 'bg-purple-900/20'
    },
    {
      name: 'NFTs',
      description: 'Non-Fungible Tokens',
      icon: Image,
      color: 'text-orange-400',
      bgColor: 'bg-orange-900/20'
    },
    {
      name: 'Scheduled',
      description: 'Scheduled Transactions',
      icon: Calendar,
      color: 'text-pink-400',
      bgColor: 'bg-pink-900/20'
    },
    {
      name: 'Account',
      description: 'Account Operations',
      icon: User,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-900/20'
    }
  ];

  const statItems = [
    { label: 'Total Transactions', value: stats.totalTransactions, icon: TrendingUp },
    { label: 'Active Tokens', value: stats.activeTokens, icon: Coins },
    { label: 'NFTs Owned', value: stats.nftsOwned, icon: Image },
    { label: 'Scheduled Txns', value: stats.scheduledTxns, icon: Calendar }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white font-mono">Dashboard</h1>
        <div className="flex items-center space-x-2 text-gray-400">
          <Network className="w-5 h-5" />
          <span className="font-mono">Testnet</span>
        </div>
      </div>

      {!isConnected ? (
        <Card className="text-center">
          <div className="py-8">
            <Activity className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Connect Your Wallet</h2>
            <p className="text-gray-400 mb-4">
              Connect your HashPack wallet to access Hedera services
            </p>
          </div>
        </Card>
      ) : (
        <>
          <Card>
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-12 h-12 bg-green-900/20 rounded-xl flex items-center justify-center">
                <User className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Connected Account</h2>
                <p className="text-gray-400 font-mono">{accountId}</p>
              </div>
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {statItems.map((item) => {
              const Icon = item.icon;
              return (
                <Card key={item.label}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm font-mono">{item.label}</p>
                      <p className="text-2xl font-bold text-white">{item.value}</p>
                    </div>
                    <Icon className="w-8 h-8 text-gray-600" />
                  </div>
                </Card>
              );
            })}
          </div>

          <Card title="Available Services">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {services.map((service) => {
                const Icon = service.icon;
                return (
                  <div
                    key={service.name}
                    className={`p-4 rounded-xl border border-gray-700 hover:border-gray-600 transition-colors ${service.bgColor}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center">
                        <Icon className={`w-5 h-5 ${service.color}`} />
                      </div>
                      <div>
                        <h3 className="font-bold text-white font-mono">{service.name}</h3>
                        <p className="text-sm text-gray-400">{service.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </>
      )}
    </div>
  );
};

export default Dashboard;