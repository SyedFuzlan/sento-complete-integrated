import React, { useState } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { nftApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import TextArea from '../components/TextArea';
import { Image, Plus, ArrowUpDown, Eye } from 'lucide-react';
import toast from 'react-hot-toast';

const NFTPage: React.FC = () => {
  const { isConnected } = useHashConnect();
  const [loading, setLoading] = useState(false);
  const [nfts, setNfts] = useState<any[]>([]);
  
  // Create NFT Collection Form
  const [collectionName, setCollectionName] = useState('');
  const [collectionSymbol, setCollectionSymbol] = useState('');
  const [initialMetadata, setInitialMetadata] = useState('');
  
  // Mint NFT Form
  const [mintTokenId, setMintTokenId] = useState('');
  const [mintMetadata, setMintMetadata] = useState('');
  
  // Transfer NFT Form
  const [transferTokenId, setTransferTokenId] = useState('');
  const [transferSerialNumber, setTransferSerialNumber] = useState('');
  const [transferFrom, setTransferFrom] = useState('');
  const [transferTo, setTransferTo] = useState('');
  
  // View NFT Form
  const [viewTokenId, setViewTokenId] = useState('');
  const [viewSerialNumber, setViewSerialNumber] = useState('');
  const [nftInfo, setNftInfo] = useState<any>(null);

  const createNFT = async () => {
    if (!collectionName.trim() || !collectionSymbol.trim()) {
      toast.error('Collection name and symbol are required');
      return;
    }

    setLoading(true);
    try {
      const metadata = initialMetadata.trim() 
        ? initialMetadata.split('\n').filter(m => m.trim())
        : [];
      
      const result = await nftApi.createNFT(collectionName, collectionSymbol, metadata);
      toast.success(`NFT collection created: ${result.tokenId}`);
      setCollectionName('');
      setCollectionSymbol('');
      setInitialMetadata('');
      
      // Add to local NFTs list
      setNfts(prev => [...prev, result]);
    } catch (error) {
      console.error('Failed to create NFT collection:', error);
      toast.error('Failed to create NFT collection');
    } finally {
      setLoading(false);
    }
  };

  const mintNFT = async () => {
    if (!mintTokenId || !mintMetadata.trim()) {
      toast.error('Token ID and metadata are required');
      return;
    }

    setLoading(true);
    try {
      const result = await nftApi.mintNFT(mintTokenId, mintMetadata);
      toast.success(`NFT minted: Serial ${result.serialNumber}`);
      setMintMetadata('');
    } catch (error) {
      console.error('Failed to mint NFT:', error);
      toast.error('Failed to mint NFT');
    } finally {
      setLoading(false);
    }
  };

  const transferNFT = async () => {
    if (!transferTokenId || !transferSerialNumber || !transferFrom || !transferTo) {
      toast.error('All transfer fields are required');
      return;
    }

    setLoading(true);
    try {
      const result = await nftApi.transferNFT(
        transferTokenId,
        transferSerialNumber,
        transferFrom,
        transferTo
      );
      toast.success(`NFT transferred: ${result.transactionId}`);
      setTransferSerialNumber('');
      setTransferFrom('');
      setTransferTo('');
    } catch (error) {
      console.error('Failed to transfer NFT:', error);
      toast.error('Failed to transfer NFT');
    } finally {
      setLoading(false);
    }
  };

  const viewNFT = async () => {
    if (!viewTokenId.trim() || !viewSerialNumber.trim()) {
      toast.error('Token ID and serial number are required');
      return;
    }

    setLoading(true);
    try {
      const result = await nftApi.getNFTInfo(viewTokenId, viewSerialNumber);
      setNftInfo(result);
    } catch (error) {
      console.error('Failed to fetch NFT info:', error);
      toast.error('Failed to fetch NFT information');
    } finally {
      setLoading(false);
    }
  };

  // Example metadata templates
  const exampleMetadata = `{
  "name": "My NFT #1",
  "description": "A unique digital artwork",
  "image": "https://example.com/image.jpg",
  "attributes": [
    {"trait_type": "Color", "value": "Blue"},
    {"trait_type": "Rarity", "value": "Rare"}
  ]
}`;

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">NFTs - Non-Fungible Tokens</h1>
        <Card className="text-center">
          <div className="py-8">
            <Image className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Wallet Not Connected</h2>
            <p className="text-gray-400">
              Connect your wallet to create and manage NFTs
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white font-mono">NFTs - Non-Fungible Tokens</h1>

      {/* Example Metadata */}
      <Card title="Example NFT Metadata">
        <div className="space-y-4">
          <TextArea
            label="JSON Metadata Format"
            value={exampleMetadata}
            onChange={() => {}}
            rows={10}
            className="font-mono"
          />
          <p className="text-gray-400 text-sm">
            Use this format when creating NFT metadata. Each line can be a separate metadata for multiple NFTs.
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Create NFT Collection */}
        <Card title="Create NFT Collection">
          <div className="space-y-4">
            <Input
              label="Collection Name"
              value={collectionName}
              onChange={(e) => setCollectionName(e.target.value)}
              placeholder="My NFT Collection"
              required
            />
            <Input
              label="Symbol"
              value={collectionSymbol}
              onChange={(e) => setCollectionSymbol(e.target.value)}
              placeholder="MNFT"
              required
            />
            <TextArea
              label="Initial Metadata (one per line)"
              value={initialMetadata}
              onChange={(e) => setInitialMetadata(e.target.value)}
              placeholder="Metadata for first NFT..."
              rows={4}
            />
            <Button onClick={createNFT} disabled={loading}>
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Collection'}
            </Button>
          </div>
        </Card>

        {/* Mint NFT */}
        <Card title="Mint NFT">
          <div className="space-y-4">
            <Input
              label="Token ID"
              value={mintTokenId}
              onChange={(e) => setMintTokenId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <TextArea
              label="Metadata (JSON)"
              value={mintMetadata}
              onChange={(e) => setMintMetadata(e.target.value)}
              placeholder='{"name": "My NFT", "description": "..."}'
              rows={4}
              required
            />
            <Button onClick={mintNFT} disabled={loading}>
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Minting...' : 'Mint NFT'}
            </Button>
          </div>
        </Card>
      </div>

      {/* Transfer NFT */}
      <Card title="Transfer NFT">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Token ID"
            value={transferTokenId}
            onChange={(e) => setTransferTokenId(e.target.value)}
            placeholder="0.0.12345"
            required
          />
          <Input
            label="Serial Number"
            value={transferSerialNumber}
            onChange={(e) => setTransferSerialNumber(e.target.value)}
            placeholder="1"
            required
          />
          <Input
            label="From Account"
            value={transferFrom}
            onChange={(e) => setTransferFrom(e.target.value)}
            placeholder="0.0.12345"
            required
          />
          <Input
            label="To Account"
            value={transferTo}
            onChange={(e) => setTransferTo(e.target.value)}
            placeholder="0.0.67890"
            required
          />
        </div>
        <div className="mt-4">
          <Button onClick={transferNFT} disabled={loading}>
            <ArrowUpDown className="w-4 h-4 mr-2" />
            {loading ? 'Transferring...' : 'Transfer NFT'}
          </Button>
        </div>
      </Card>

      {/* View NFT */}
      <Card title="View NFT Information">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Token ID"
              value={viewTokenId}
              onChange={(e) => setViewTokenId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <Input
              label="Serial Number"
              value={viewSerialNumber}
              onChange={(e) => setViewSerialNumber(e.target.value)}
              placeholder="1"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={viewNFT} disabled={loading}>
                <Eye className="w-4 h-4 mr-2" />
                {loading ? 'Loading...' : 'View NFT'}
              </Button>
            </div>
          </div>

          {nftInfo && (
            <div className="p-4 bg-gray-800 rounded-xl">
              <h3 className="font-bold text-white mb-2">NFT Information</h3>
              <div className="space-y-2">
                <p><span className="text-gray-400">Token ID:</span> <span className="text-white font-mono">{nftInfo.tokenId}</span></p>
                <p><span className="text-gray-400">Serial Number:</span> <span className="text-white">{nftInfo.serialNumber}</span></p>
                <p><span className="text-gray-400">Owner:</span> <span className="text-white font-mono">{nftInfo.accountId}</span></p>
                {nftInfo.metadata && (
                  <div>
                    <p className="text-gray-400">Metadata:</p>
                    <pre className="text-white font-mono text-xs bg-gray-700 p-2 rounded mt-1 overflow-auto">
                      {JSON.stringify(JSON.parse(nftInfo.metadata), null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Recent NFTs */}
      {nfts.length > 0 && (
        <Card title="Recent NFT Collections">
          <div className="space-y-2">
            {nfts.map((nft, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                <div>
                  <p className="text-white font-mono">{nft.tokenId}</p>
                  <p className="text-gray-400 text-sm">{nft.name} ({nft.symbol})</p>
                </div>
                <Button
                  variant="secondary"
                  onClick={() => setMintTokenId(nft.tokenId)}
                >
                  Use
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default NFTPage;