import React, { useState } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { hscsApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import TextArea from '../components/TextArea';
import { FileText, Upload, Play, Eye } from 'lucide-react';
import toast from 'react-hot-toast';

const HSCSPage: React.FC = () => {
  const { isConnected } = useHashConnect();
  const [loading, setLoading] = useState(false);
  const [contracts, setContracts] = useState<any[]>([]);
  
  // Deploy Contract Form
  const [bytecode, setBytecode] = useState('');
  const [deployGas, setDeployGas] = useState('100000');
  
  // Call Contract Form
  const [callContractId, setCallContractId] = useState('');
  const [functionName, setFunctionName] = useState('');
  const [parameters, setParameters] = useState('[]');
  const [callGas, setCallGas] = useState('50000');
  
  // View Contract Form
  const [viewContractId, setViewContractId] = useState('');
  const [contractInfo, setContractInfo] = useState<any>(null);

  const deployContract = async () => {
    if (!bytecode.trim()) {
      toast.error('Bytecode is required');
      return;
    }

    setLoading(true);
    try {
      const result = await hscsApi.deployContract(bytecode, parseInt(deployGas));
      toast.success(`Contract deployed: ${result.contractId}`);
      setBytecode('');
      setDeployGas('100000');
      
      // Add to local contracts list
      setContracts(prev => [...prev, result]);
    } catch (error) {
      console.error('Failed to deploy contract:', error);
      toast.error('Failed to deploy contract');
    } finally {
      setLoading(false);
    }
  };

  const callContract = async () => {
    if (!callContractId || !functionName.trim()) {
      toast.error('Contract ID and function name are required');
      return;
    }

    setLoading(true);
    try {
      let parsedParameters = [];
      if (parameters.trim()) {
        parsedParameters = JSON.parse(parameters);
      }
      
      const result = await hscsApi.callContract(
        callContractId,
        functionName,
        parsedParameters,
        parseInt(callGas)
      );
      
      toast.success(`Contract called: ${result.transactionId}`);
      setFunctionName('');
      setParameters('[]');
    } catch (error) {
      console.error('Failed to call contract:', error);
      toast.error('Failed to call contract');
    } finally {
      setLoading(false);
    }
  };

  const viewContract = async () => {
    if (!viewContractId.trim()) {
      toast.error('Contract ID is required');
      return;
    }

    setLoading(true);
    try {
      const result = await hscsApi.getContractInfo(viewContractId);
      setContractInfo(result);
    } catch (error) {
      console.error('Failed to fetch contract info:', error);
      toast.error('Failed to fetch contract information');
    } finally {
      setLoading(false);
    }
  };

  // Example Solidity contract for demo
  const exampleContract = `pragma solidity ^0.8.0;

contract SimpleStorage {
    uint256 private storedData;
    
    function set(uint256 x) public {
        storedData = x;
    }
    
    function get() public view returns (uint256) {
        return storedData;
    }
}`;

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">HSCS - Hedera Smart Contract Service</h1>
        <Card className="text-center">
          <div className="py-8">
            <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Wallet Not Connected</h2>
            <p className="text-gray-400">
              Connect your wallet to use the Hedera Smart Contract Service
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white font-mono">HSCS - Hedera Smart Contract Service</h1>

      {/* Example Contract */}
      <Card title="Example Solidity Contract">
        <div className="space-y-4">
          <TextArea
            label="Solidity Code (for reference)"
            value={exampleContract}
            onChange={() => {}}
            rows={8}
            className="font-mono"
          />
          <p className="text-gray-400 text-sm">
            Compile this contract to get bytecode, then deploy it using the form below.
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Deploy Contract */}
        <Card title="Deploy Contract">
          <div className="space-y-4">
            <TextArea
              label="Bytecode"
              value={bytecode}
              onChange={(e) => setBytecode(e.target.value)}
              placeholder="0x608060405234801561001057600080fd5b50..."
              rows={6}
              required
            />
            <Input
              label="Gas Limit"
              type="number"
              value={deployGas}
              onChange={(e) => setDeployGas(e.target.value)}
              placeholder="100000"
              required
            />
            <Button onClick={deployContract} disabled={loading}>
              <Upload className="w-4 h-4 mr-2" />
              {loading ? 'Deploying...' : 'Deploy Contract'}
            </Button>
          </div>
        </Card>

        {/* Call Contract */}
        <Card title="Call Contract">
          <div className="space-y-4">
            <Input
              label="Contract ID"
              value={callContractId}
              onChange={(e) => setCallContractId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <Input
              label="Function Name"
              value={functionName}
              onChange={(e) => setFunctionName(e.target.value)}
              placeholder="set"
              required
            />
            <TextArea
              label="Parameters (JSON Array)"
              value={parameters}
              onChange={(e) => setParameters(e.target.value)}
              placeholder='[42]'
              rows={3}
            />
            <Input
              label="Gas Limit"
              type="number"
              value={callGas}
              onChange={(e) => setCallGas(e.target.value)}
              placeholder="50000"
              required
            />
            <Button onClick={callContract} disabled={loading}>
              <Play className="w-4 h-4 mr-2" />
              {loading ? 'Calling...' : 'Call Contract'}
            </Button>
          </div>
        </Card>
      </div>

      {/* View Contract */}
      <Card title="View Contract Information">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Contract ID"
              value={viewContractId}
              onChange={(e) => setViewContractId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={viewContract} disabled={loading}>
                <Eye className="w-4 h-4 mr-2" />
                {loading ? 'Loading...' : 'View Contract'}
              </Button>
            </div>
          </div>

          {contractInfo && (
            <div className="p-4 bg-gray-800 rounded-xl">
              <h3 className="font-bold text-white mb-2">Contract Information</h3>
              <div className="space-y-2">
                <p><span className="text-gray-400">Contract ID:</span> <span className="text-white font-mono">{contractInfo.contractId}</span></p>
                <p><span className="text-gray-400">Gas Used:</span> <span className="text-white">{contractInfo.gasUsed}</span></p>
                <p><span className="text-gray-400">Created:</span> <span className="text-white">{contractInfo.createdAt}</span></p>
                {contractInfo.bytecode && (
                  <div>
                    <p className="text-gray-400">Bytecode:</p>
                    <code className="text-white font-mono text-xs bg-gray-700 p-2 rounded block mt-1 break-all">
                      {contractInfo.bytecode.substring(0, 100)}...
                    </code>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Recent Contracts */}
      {contracts.length > 0 && (
        <Card title="Recent Contracts">
          <div className="space-y-2">
            {contracts.map((contract, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                <div>
                  <p className="text-white font-mono">{contract.contractId}</p>
                  <p className="text-gray-400 text-sm">Gas: {contract.gas}</p>
                </div>
                <Button
                  variant="secondary"
                  onClick={() => setCallContractId(contract.contractId)}
                >
                  Use
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default HSCSPage;