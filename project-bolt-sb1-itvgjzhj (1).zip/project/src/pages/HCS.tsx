import React, { useState, useEffect } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { hcsApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import TextArea from '../components/TextArea';
import { MessageCircle, Send, Plus, Eye } from 'lucide-react';
import toast from 'react-hot-toast';

const HCSPage: React.FC = () => {
  const { isConnected } = useHashConnect();
  const [loading, setLoading] = useState(false);
  const [topics, setTopics] = useState<any[]>([]);
  
  // Create Topic Form
  const [topicMemo, setTopicMemo] = useState('');
  const [adminKey, setAdminKey] = useState('');
  
  // Submit Message Form
  const [selectedTopicId, setSelectedTopicId] = useState('');
  const [message, setMessage] = useState('');
  
  // View Topic Form
  const [viewTopicId, setViewTopicId] = useState('');
  const [topicInfo, setTopicInfo] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);

  const createTopic = async () => {
    if (!topicMemo.trim()) {
      toast.error('Topic memo is required');
      return;
    }

    setLoading(true);
    try {
      const result = await hcsApi.createTopic(topicMemo, adminKey || undefined);
      toast.success(`Topic created: ${result.topicId}`);
      setTopicMemo('');
      setAdminKey('');
      
      // Add to local topics list
      setTopics(prev => [...prev, result]);
    } catch (error) {
      console.error('Failed to create topic:', error);
      toast.error('Failed to create topic');
    } finally {
      setLoading(false);
    }
  };

  const submitMessage = async () => {
    if (!selectedTopicId || !message.trim()) {
      toast.error('Topic ID and message are required');
      return;
    }

    setLoading(true);
    try {
      const result = await hcsApi.submitMessage(selectedTopicId, message);
      toast.success(`Message submitted: ${result.transactionId}`);
      setMessage('');
    } catch (error) {
      console.error('Failed to submit message:', error);
      toast.error('Failed to submit message');
    } finally {
      setLoading(false);
    }
  };

  const viewTopic = async () => {
    if (!viewTopicId.trim()) {
      toast.error('Topic ID is required');
      return;
    }

    setLoading(true);
    try {
      const [topicResult, messagesResult] = await Promise.all([
        hcsApi.getTopicInfo(viewTopicId),
        hcsApi.getMessages(viewTopicId)
      ]);
      
      setTopicInfo(topicResult);
      setMessages(messagesResult.messages || []);
    } catch (error) {
      console.error('Failed to fetch topic info:', error);
      toast.error('Failed to fetch topic information');
    } finally {
      setLoading(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">HCS - Hedera Consensus Service</h1>
        <Card className="text-center">
          <div className="py-8">
            <MessageCircle className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Wallet Not Connected</h2>
            <p className="text-gray-400">
              Connect your wallet to use the Hedera Consensus Service
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white font-mono">HCS - Hedera Consensus Service</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Create Topic */}
        <Card title="Create Topic">
          <div className="space-y-4">
            <Input
              label="Topic Memo"
              value={topicMemo}
              onChange={(e) => setTopicMemo(e.target.value)}
              placeholder="Enter topic description"
              required
            />
            <Input
              label="Admin Key (Optional)"
              value={adminKey}
              onChange={(e) => setAdminKey(e.target.value)}
              placeholder="Enter admin key"
            />
            <Button onClick={createTopic} disabled={loading}>
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Topic'}
            </Button>
          </div>
        </Card>

        {/* Submit Message */}
        <Card title="Submit Message">
          <div className="space-y-4">
            <Input
              label="Topic ID"
              value={selectedTopicId}
              onChange={(e) => setSelectedTopicId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <TextArea
              label="Message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your message"
              required
            />
            <Button onClick={submitMessage} disabled={loading}>
              <Send className="w-4 h-4 mr-2" />
              {loading ? 'Submitting...' : 'Submit Message'}
            </Button>
          </div>
        </Card>
      </div>

      {/* View Topic */}
      <Card title="View Topic Information">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Topic ID"
              value={viewTopicId}
              onChange={(e) => setViewTopicId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={viewTopic} disabled={loading}>
                <Eye className="w-4 h-4 mr-2" />
                {loading ? 'Loading...' : 'View Topic'}
              </Button>
            </div>
          </div>

          {topicInfo && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-800 rounded-xl">
                <h3 className="font-bold text-white mb-2">Topic Information</h3>
                <div className="space-y-2">
                  <p><span className="text-gray-400">Topic ID:</span> <span className="text-white font-mono">{topicInfo.topicId}</span></p>
                  <p><span className="text-gray-400">Memo:</span> <span className="text-white">{topicInfo.memo}</span></p>
                  <p><span className="text-gray-400">Submit Key:</span> <span className="text-white font-mono">{topicInfo.submitKey || 'None'}</span></p>
                </div>
              </div>

              {messages.length > 0 && (
                <div className="p-4 bg-gray-800 rounded-xl">
                  <h3 className="font-bold text-white mb-2">Messages ({messages.length})</h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {messages.map((msg, index) => (
                      <div key={index} className="p-2 bg-gray-700 rounded-lg">
                        <p className="text-white text-sm">{msg.message}</p>
                        <p className="text-gray-400 text-xs mt-1">
                          {new Date(msg.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* Recent Topics */}
      {topics.length > 0 && (
        <Card title="Recent Topics">
          <div className="space-y-2">
            {topics.map((topic, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                <div>
                  <p className="text-white font-mono">{topic.topicId}</p>
                  <p className="text-gray-400 text-sm">{topic.memo}</p>
                </div>
                <Button
                  variant="secondary"
                  onClick={() => setSelectedTopicId(topic.topicId)}
                >
                  Use
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default HCSPage;