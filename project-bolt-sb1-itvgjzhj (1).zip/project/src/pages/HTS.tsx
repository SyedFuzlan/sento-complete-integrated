import React, { useState } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { htsApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import { Coins, Plus, ArrowUpDown, Eye, Flame } from 'lucide-react';
import toast from 'react-hot-toast';

const HTSPage: React.FC = () => {
  const { isConnected } = useHashConnect();
  const [loading, setLoading] = useState(false);
  const [tokens, setTokens] = useState<any[]>([]);
  
  // Create Token Form
  const [tokenName, setTokenName] = useState('');
  const [tokenSymbol, setTokenSymbol] = useState('');
  const [tokenDecimals, setTokenDecimals] = useState('2');
  const [initialSupply, setInitialSupply] = useState('1000');
  
  // Token Operations
  const [operationTokenId, setOperationTokenId] = useState('');
  const [operationAmount, setOperationAmount] = useState('');
  
  // Transfer Form
  const [transferTokenId, setTransferTokenId] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferFrom, setTransferFrom] = useState('');
  const [transferTo, setTransferTo] = useState('');
  
  // View Token Form
  const [viewTokenId, setViewTokenId] = useState('');
  const [tokenInfo, setTokenInfo] = useState<any>(null);

  const createToken = async () => {
    if (!tokenName.trim() || !tokenSymbol.trim()) {
      toast.error('Token name and symbol are required');
      return;
    }

    setLoading(true);
    try {
      const result = await htsApi.createToken(
        tokenName,
        tokenSymbol,
        parseInt(tokenDecimals),
        initialSupply
      );
      
      toast.success(`Token created: ${result.tokenId}`);
      setTokenName('');
      setTokenSymbol('');
      setTokenDecimals('2');
      setInitialSupply('1000');
      
      // Add to local tokens list
      setTokens(prev => [...prev, result]);
    } catch (error) {
      console.error('Failed to create token:', error);
      toast.error('Failed to create token');
    } finally {
      setLoading(false);
    }
  };

  const mintToken = async () => {
    if (!operationTokenId || !operationAmount) {
      toast.error('Token ID and amount are required');
      return;
    }

    setLoading(true);
    try {
      const result = await htsApi.mintToken(operationTokenId, operationAmount);
      toast.success(`Tokens minted: ${result.transactionId}`);
      setOperationAmount('');
    } catch (error) {
      console.error('Failed to mint token:', error);
      toast.error('Failed to mint token');
    } finally {
      setLoading(false);
    }
  };

  const burnToken = async () => {
    if (!operationTokenId || !operationAmount) {
      toast.error('Token ID and amount are required');
      return;
    }

    setLoading(true);
    try {
      const result = await htsApi.burnToken(operationTokenId, operationAmount);
      toast.success(`Tokens burned: ${result.transactionId}`);
      setOperationAmount('');
    } catch (error) {
      console.error('Failed to burn token:', error);
      toast.error('Failed to burn token');
    } finally {
      setLoading(false);
    }
  };

  const transferToken = async () => {
    if (!transferTokenId || !transferAmount || !transferFrom || !transferTo) {
      toast.error('All transfer fields are required');
      return;
    }

    setLoading(true);
    try {
      const result = await htsApi.transferToken(
        transferTokenId,
        transferFrom,
        transferTo,
        transferAmount
      );
      toast.success(`Token transferred: ${result.transactionId}`);
      setTransferAmount('');
      setTransferFrom('');
      setTransferTo('');
    } catch (error) {
      console.error('Failed to transfer token:', error);
      toast.error('Failed to transfer token');
    } finally {
      setLoading(false);
    }
  };

  const viewToken = async () => {
    if (!viewTokenId.trim()) {
      toast.error('Token ID is required');
      return;
    }

    setLoading(true);
    try {
      const result = await htsApi.getTokenInfo(viewTokenId);
      setTokenInfo(result);
    } catch (error) {
      console.error('Failed to fetch token info:', error);
      toast.error('Failed to fetch token information');
    } finally {
      setLoading(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">HTS - Hedera Token Service</h1>
        <Card className="text-center">
          <div className="py-8">
            <Coins className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Wallet Not Connected</h2>
            <p className="text-gray-400">
              Connect your wallet to use the Hedera Token Service
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white font-mono">HTS - Hedera Token Service</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Create Token */}
        <Card title="Create Token">
          <div className="space-y-4">
            <Input
              label="Token Name"
              value={tokenName}
              onChange={(e) => setTokenName(e.target.value)}
              placeholder="My Token"
              required
            />
            <Input
              label="Symbol"
              value={tokenSymbol}
              onChange={(e) => setTokenSymbol(e.target.value)}
              placeholder="MTK"
              required
            />
            <Input
              label="Decimals"
              type="number"
              value={tokenDecimals}
              onChange={(e) => setTokenDecimals(e.target.value)}
              placeholder="2"
              required
            />
            <Input
              label="Initial Supply"
              type="number"
              value={initialSupply}
              onChange={(e) => setInitialSupply(e.target.value)}
              placeholder="1000"
              required
            />
            <Button onClick={createToken} disabled={loading}>
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Token'}
            </Button>
          </div>
        </Card>

        {/* Token Operations */}
        <Card title="Token Operations">
          <div className="space-y-4">
            <Input
              label="Token ID"
              value={operationTokenId}
              onChange={(e) => setOperationTokenId(e.target.value)}
              placeholder="0.0.12345"
              required
            />
            <Input
              label="Amount"
              type="number"
              value={operationAmount}
              onChange={(e) => setOperationAmount(e.target.value)}
              placeholder="100"
              required
            />
            <div className="flex space-x-2">
              <Button onClick={mintToken} disabled={loading} className="flex-1">
                <Plus className="w-4 h-4 mr-2" />
                Mint
              </Button>
              <Button onClick={burnToken} disabled={loading} variant="danger" className="flex-1">
                <Flame className="w-4 h-4 mr-2" />
                Burn
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Transfer Tokens */}
      <Card title="Transfer Tokens">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Token ID"
            value={transferTokenId}
            onChange={(e) => setTransferTokenId(e.target.value)}
            placeholder="0.0.12345"
            required
          />
          <Input
            label="Amount"
            type="number"
            value={transferAmount}
            onChange={(e) => setTransferAmount(e.target.value)}
            placeholder="100"
            required
          />
          <Input
            label="From Account"
            value={transferFrom}
            onChange={(e) => setTransferFrom(e.target.value)}
            placeholder="0.0.12345"
            required
          />
          <Input
            label="To Account"
            value={transferTo}
            onChange={(e) => setTransferTo(e.target.value)}
            placeholder="0.0.67890"
            required
          />
        </div>
        <div className="mt-4">
          <Button onClick={transferToken} disabled={loading}>
            <ArrowUpDown className="w-4 h-4 mr-2" />
            {loading ? 'Transferring...' : 'Transfer Tokens'}
          </Button>
        </div>
      </Card>

      {/* View Token */}
      <Card title="View Token Information">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <Input
              label="Token ID"
              value={viewTokenId}
              onChange={(e) => setViewTokenId(e.target.value)}
              placeholder="0.0.12345"
              className="flex-1"
            />
            <div className="flex items-end">
              <Button onClick={viewToken} disabled={loading}>
                <Eye className="w-4 h-4 mr-2" />
                {loading ? 'Loading...' : 'View Token'}
              </Button>
            </div>
          </div>

          {tokenInfo && (
            <div className="p-4 bg-gray-800 rounded-xl">
              <h3 className="font-bold text-white mb-2">Token Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p><span className="text-gray-400">Token ID:</span> <span className="text-white font-mono">{tokenInfo.tokenId}</span></p>
                  <p><span className="text-gray-400">Name:</span> <span className="text-white">{tokenInfo.name}</span></p>
                  <p><span className="text-gray-400">Symbol:</span> <span className="text-white">{tokenInfo.symbol}</span></p>
                </div>
                <div>
                  <p><span className="text-gray-400">Decimals:</span> <span className="text-white">{tokenInfo.decimals}</span></p>
                  <p><span className="text-gray-400">Total Supply:</span> <span className="text-white">{tokenInfo.totalSupply}</span></p>
                </div>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Recent Tokens */}
      {tokens.length > 0 && (
        <Card title="Recent Tokens">
          <div className="space-y-2">
            {tokens.map((token, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl">
                <div>
                  <p className="text-white font-mono">{token.tokenId}</p>
                  <p className="text-gray-400 text-sm">{token.name} ({token.symbol})</p>
                </div>
                <Button
                  variant="secondary"
                  onClick={() => setOperationTokenId(token.tokenId)}
                >
                  Use
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default HTSPage;