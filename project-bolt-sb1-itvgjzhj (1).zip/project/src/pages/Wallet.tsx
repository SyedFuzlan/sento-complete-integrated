import React, { useState, useEffect } from 'react';
import { useHashConnect } from '../hooks/useHashConnect';
import { accountApi } from '../services/api';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import { Wallet, Copy, ExternalLink, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

const WalletPage: React.FC = () => {
  const { isConnected, accountId } = useHashConnect();
  const [balance, setBalance] = useState('0');
  const [accountInfo, setAccountInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [newAccountBalance, setNewAccountBalance] = useState('10');

  const fetchAccountInfo = async () => {
    if (!accountId) return;
    
    setLoading(true);
    try {
      const [balanceResult, infoResult] = await Promise.all([
        accountApi.getAccountBalance(accountId),
        accountApi.getAccountInfo(accountId)
      ]);
      
      setBalance(balanceResult.balance || '0');
      setAccountInfo(infoResult);
    } catch (error) {
      console.error('Failed to fetch account info:', error);
      toast.error('Failed to fetch account information');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success('Copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy');
    }
  };

  const createNewAccount = async () => {
    setLoading(true);
    try {
      const result = await accountApi.createAccount(newAccountBalance);
      toast.success(`New account created: ${result.accountId}`);
      setNewAccountBalance('10');
    } catch (error) {
      console.error('Failed to create account:', error);
      toast.error('Failed to create account');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isConnected && accountId) {
      fetchAccountInfo();
    }
  }, [isConnected, accountId]);

  if (!isConnected) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-white font-mono">Wallet</h1>
        <Card className="text-center">
          <div className="py-8">
            <Wallet className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">No Wallet Connected</h2>
            <p className="text-gray-400">
              Connect your HashPack wallet to view account information
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white font-mono">Wallet</h1>
        <Button onClick={fetchAccountInfo} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <Card title="Account Information">
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-800 rounded-xl">
            <div>
              <p className="text-gray-400 text-sm font-mono">Account ID</p>
              <p className="text-white font-mono">{accountId}</p>
            </div>
            <div className="flex space-x-2">
              <Button 
                variant="secondary" 
                onClick={() => copyToClipboard(accountId)}
              >
                <Copy className="w-4 h-4" />
              </Button>
              <Button 
                variant="secondary" 
                onClick={() => window.open(`https://testnet.dragonglass.me/accounts/${accountId}`, '_blank')}
              >
                <ExternalLink className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-800 rounded-xl">
            <div>
              <p className="text-gray-400 text-sm font-mono">Balance</p>
              <p className="text-white font-mono text-xl">{balance} ℏ</p>
            </div>
          </div>

          {accountInfo && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-800 rounded-xl">
                <p className="text-gray-400 text-sm font-mono">Public Key</p>
                <p className="text-white font-mono text-sm break-all">
                  {accountInfo.publicKey || 'N/A'}
                </p>
              </div>
              <div className="p-4 bg-gray-800 rounded-xl">
                <p className="text-gray-400 text-sm font-mono">Created</p>
                <p className="text-white font-mono">
                  {accountInfo.createdAt ? new Date(accountInfo.createdAt).toLocaleDateString() : 'N/A'}
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      <Card title="Create New Account">
        <div className="space-y-4">
          <Input
            label="Initial Balance (ℏ)"
            type="number"
            value={newAccountBalance}
            onChange={(e) => setNewAccountBalance(e.target.value)}
            placeholder="10"
            required
          />
          <Button onClick={createNewAccount} disabled={loading}>
            {loading ? 'Creating...' : 'Create Account'}
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default WalletPage;