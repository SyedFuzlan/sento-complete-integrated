import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Dashboard from './pages/Dashboard';
import WalletPage from './pages/Wallet';
import HCSPage from './pages/HCS';
import HTSPage from './pages/HTS';
import HSCSPage from './pages/HSCS';
import NFTPage from './pages/NFT';
import ScheduledPage from './pages/Scheduled';
import AccountPage from './pages/Account';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-900 flex">
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <Topbar />
          <main className="flex-1 p-6 overflow-auto">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/wallet" element={<WalletPage />} />
              <Route path="/hcs" element={<HCSPage />} />
              <Route path="/hts" element={<HTSPage />} />
              <Route path="/hscs" element={<HSCSPage />} />
              <Route path="/nft" element={<NFTPage />} />
              <Route path="/scheduled" element={<ScheduledPage />} />
              <Route path="/account" element={<AccountPage />} />
            </Routes>
          </main>
        </div>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#111827',
              color: '#f9fafb',
              border: '1px solid #374151',
            },
          }}
        />
      </div>
    </Router>
  );
}

export default App;