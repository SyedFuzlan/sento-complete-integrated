import axios from 'axios';

const API_BASE_URL = 'http://localhost:3001/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// HCS (Consensus Service) APIs
export const hcsApi = {
  createTopic: async (memo: string, adminKey?: string) => {
    const response = await api.post('/hcs/create-topic', { memo, adminKey });
    return response.data;
  },
  
  submitMessage: async (topicId: string, message: string) => {
    const response = await api.post('/hcs/submit-message', { topicId, message });
    return response.data;
  },
  
  getTopicInfo: async (topicId: string) => {
    const response = await api.get(`/hcs/topic/${topicId}`);
    return response.data;
  },
  
  getMessages: async (topicId: string) => {
    const response = await api.get(`/hcs/messages/${topicId}`);
    return response.data;
  }
};

// HTS (Token Service) APIs
export const htsApi = {
  createToken: async (name: string, symbol: string, decimals: number, initialSupply: string) => {
    const response = await api.post('/hts/create-token', { name, symbol, decimals, initialSupply });
    return response.data;
  },
  
  mintToken: async (tokenId: string, amount: string) => {
    const response = await api.post('/hts/mint-token', { tokenId, amount });
    return response.data;
  },
  
  burnToken: async (tokenId: string, amount: string) => {
    const response = await api.post('/hts/burn-token', { tokenId, amount });
    return response.data;
  },
  
  transferToken: async (tokenId: string, fromAccountId: string, toAccountId: string, amount: string) => {
    const response = await api.post('/hts/transfer-token', { tokenId, fromAccountId, toAccountId, amount });
    return response.data;
  },
  
  getTokenInfo: async (tokenId: string) => {
    const response = await api.get(`/hts/token/${tokenId}`);
    return response.data;
  }
};

// HSCS (Smart Contract Service) APIs
export const hscsApi = {
  deployContract: async (bytecode: string, gas: number) => {
    const response = await api.post('/hscs/deploy-contract', { bytecode, gas });
    return response.data;
  },
  
  callContract: async (contractId: string, functionName: string, parameters: any[], gas: number) => {
    const response = await api.post('/hscs/call-contract', { contractId, functionName, parameters, gas });
    return response.data;
  },
  
  getContractInfo: async (contractId: string) => {
    const response = await api.get(`/hscs/contract/${contractId}`);
    return response.data;
  }
};

// NFT APIs
export const nftApi = {
  createNFT: async (name: string, symbol: string, metadata: string[]) => {
    const response = await api.post('/nft/create-nft', { name, symbol, metadata });
    return response.data;
  },
  
  mintNFT: async (tokenId: string, metadata: string) => {
    const response = await api.post('/nft/mint-nft', { tokenId, metadata });
    return response.data;
  },
  
  transferNFT: async (tokenId: string, serialNumber: string, fromAccountId: string, toAccountId: string) => {
    const response = await api.post('/nft/transfer-nft', { tokenId, serialNumber, fromAccountId, toAccountId });
    return response.data;
  },
  
  getNFTInfo: async (tokenId: string, serialNumber: string) => {
    const response = await api.get(`/nft/${tokenId}/${serialNumber}`);
    return response.data;
  }
};

// Account Operations APIs
export const accountApi = {
  createAccount: async (initialBalance: string) => {
    const response = await api.post('/account/create-account', { initialBalance });
    return response.data;
  },
  
  getAccountInfo: async (accountId: string) => {
    const response = await api.get(`/account/${accountId}`);
    return response.data;
  },
  
  getAccountBalance: async (accountId: string) => {
    const response = await api.get(`/account/balance/${accountId}`);
    return response.data;
  },
  
  freezeAccount: async (accountId: string, tokenId: string) => {
    const response = await api.post('/account/freeze', { accountId, tokenId });
    return response.data;
  },
  
  unfreezeAccount: async (accountId: string, tokenId: string) => {
    const response = await api.post('/account/unfreeze', { accountId, tokenId });
    return response.data;
  },
  
  wipeAccount: async (accountId: string, tokenId: string, amount: string) => {
    const response = await api.post('/account/wipe', { accountId, tokenId, amount });
    return response.data;
  }
};

// Scheduled Transactions APIs
export const scheduledApi = {
  createScheduledTransaction: async (payerAccountId: string, transactionBody: any, memo?: string) => {
    const response = await api.post('/scheduled/create', { payerAccountId, transactionBody, memo });
    return response.data;
  },
  
  signScheduledTransaction: async (scheduleId: string, signature: string) => {
    const response = await api.post('/scheduled/sign', { scheduleId, signature });
    return response.data;
  },
  
  executeScheduledTransaction: async (scheduleId: string) => {
    const response = await api.post('/scheduled/execute', { scheduleId });
    return response.data;
  },
  
  getScheduledTransactionInfo: async (scheduleId: string) => {
    const response = await api.get(`/scheduled/${scheduleId}`);
    return response.data;
  }
};