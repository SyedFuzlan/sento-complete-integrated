# Sento - Hedera DApp

A comprehensive Web DApp built with React, TypeScript, and Tailwind CSS for interacting with all Hedera services.

## Features

- **Wallet Integration**: HashConnect wallet connection with HashPack
- **HCS**: Hedera Consensus Service for topic creation and message submission
- **HTS**: Hedera Token Service for fungible token operations
- **HSCS**: Hedera Smart Contract Service for contract deployment and execution
- **NFTs**: Non-Fungible Token creation, minting, and transfer
- **Scheduled Transactions**: Multi-signature transaction scheduling
- **Account Operations**: Account creation, freezing, unfreezing, and wiping

## Tech Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS for styling
- React Router for navigation
- HashConnect for wallet integration
- Axios for API communication
- React Hot Toast for notifications

### Backend
- Node.js with Express
- Hedera JavaScript SDK
- RESTful API endpoints for all services

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- HashPack wallet extension
- Hedera testnet account

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   cd backend && npm install
   ```

3. Set up environment variables:
   ```bash
   cp backend/.env.example backend/.env
   ```
   Edit `backend/.env` with your Hedera credentials:
   ```
   HEDERA_NETWORK=testnet
   HEDERA_ACCOUNT_ID=your_account_id
   HEDERA_PRIVATE_KEY=your_private_key
   ```

4. Start the backend server:
   ```bash
   cd backend
   npm run dev
   ```

5. Start the frontend development server:
   ```bash
   npm run dev
   ```

The application will be available at `http://localhost:5173`

## Project Structure

```
├── src/
│   ├── components/          # Reusable UI components
│   ├── hooks/              # Custom React hooks
│   ├── pages/              # Page components
│   ├── services/           # API service functions
│   ├── types/              # TypeScript type definitions
│   └── App.tsx             # Main application component
├── backend/
│   ├── config/             # Hedera client configuration
│   ├── routes/             # API route handlers
│   └── server.js           # Express server setup
└── README.md
```

## API Endpoints

### HCS (Consensus Service)
- `POST /api/hcs/create-topic` - Create a new topic
- `POST /api/hcs/submit-message` - Submit message to topic
- `GET /api/hcs/topic/:topicId` - Get topic information
- `GET /api/hcs/messages/:topicId` - Get topic messages

### HTS (Token Service)
- `POST /api/hts/create-token` - Create fungible token
- `POST /api/hts/mint-token` - Mint tokens
- `POST /api/hts/burn-token` - Burn tokens
- `POST /api/hts/transfer-token` - Transfer tokens
- `GET /api/hts/token/:tokenId` - Get token information

### HSCS (Smart Contract Service)
- `POST /api/hscs/deploy-contract` - Deploy smart contract
- `POST /api/hscs/call-contract` - Call contract function
- `GET /api/hscs/contract/:contractId` - Get contract information

### NFT Service
- `POST /api/nft/create-nft` - Create NFT collection
- `POST /api/nft/mint-nft` - Mint NFT
- `POST /api/nft/transfer-nft` - Transfer NFT
- `GET /api/nft/:tokenId/:serialNumber` - Get NFT information

### Account Operations
- `POST /api/account/create-account` - Create account
- `GET /api/account/:accountId` - Get account information
- `GET /api/account/balance/:accountId` - Get account balance
- `POST /api/account/freeze` - Freeze account
- `POST /api/account/unfreeze` - Unfreeze account
- `POST /api/account/wipe` - Wipe account

### Scheduled Transactions
- `POST /api/scheduled/create` - Create scheduled transaction
- `POST /api/scheduled/sign` - Sign scheduled transaction
- `GET /api/scheduled/:scheduleId` - Get scheduled transaction info

## Usage

1. **Connect Wallet**: Click "Connect Wallet" in the top bar to connect your HashPack wallet
2. **Navigate Services**: Use the sidebar to navigate between different Hedera services
3. **Interact with Services**: Each service page provides forms to interact with the respective Hedera service
4. **View Results**: Transaction results and information are displayed in cards with proper formatting

## Development

The application uses a modular architecture with:
- Reusable components for consistent UI
- Custom hooks for wallet management
- Type-safe API calls with TypeScript
- Responsive design with Tailwind CSS
- Dark mode theme throughout

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License.