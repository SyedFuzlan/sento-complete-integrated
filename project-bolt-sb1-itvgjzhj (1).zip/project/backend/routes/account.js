const express = require('express');
const { 
  AccountCreateTransaction, 
  AccountInfoQuery,
  AccountBalanceQuery,
  TokenFreezeTransaction,
  TokenUnfreezeTransaction,
  TokenWipeTransaction,
  AccountId,
  TokenId,
  Hbar
} = require('@hashgraph/sdk');
const { getHederaClient } = require('../config/hedera');

const router = express.Router();

// Create a new account
router.post('/create-account', async (req, res) => {
  try {
    const { initialBalance } = req.body;
    const client = getHederaClient();

    const transaction = new AccountCreateTransaction()
      .setInitialBalance(Hbar.fromString(initialBalance));

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);
    const accountId = receipt.accountId;

    res.json({
      success: true,
      accountId: accountId.toString(),
      transactionId: txResponse.transactionId.toString(),
      balance: initialBalance
    });
  } catch (error) {
    console.error('Error creating account:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get account information
router.get('/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const client = getHederaClient();

    const query = new AccountInfoQuery()
      .setAccountId(AccountId.fromString(accountId));

    const info = await query.execute(client);

    res.json({
      success: true,
      accountId: info.accountId.toString(),
      balance: info.balance.toString(),
      publicKey: info.key.toString(),
      deleted: info.isDeleted
    });
  } catch (error) {
    console.error('Error getting account info:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get account balance
router.get('/balance/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const client = getHederaClient();

    const query = new AccountBalanceQuery()
      .setAccountId(AccountId.fromString(accountId));

    const balance = await query.execute(client);

    res.json({
      success: true,
      accountId: accountId,
      balance: balance.hbars.toString(),
      tokens: balance.tokens ? Object.entries(balance.tokens).map(([tokenId, amount]) => ({
        tokenId,
        balance: amount.toString()
      })) : []
    });
  } catch (error) {
    console.error('Error getting account balance:', error);
    res.status(500).json({ error: error.message });
  }
});

// Freeze account
router.post('/freeze', async (req, res) => {
  try {
    const { accountId, tokenId } = req.body;
    const client = getHederaClient();

    const transaction = new TokenFreezeTransaction()
      .setAccountId(AccountId.fromString(accountId))
      .setTokenId(TokenId.fromString(tokenId));

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString()
    });
  } catch (error) {
    console.error('Error freezing account:', error);
    res.status(500).json({ error: error.message });
  }
});

// Unfreeze account
router.post('/unfreeze', async (req, res) => {
  try {
    const { accountId, tokenId } = req.body;
    const client = getHederaClient();

    const transaction = new TokenUnfreezeTransaction()
      .setAccountId(AccountId.fromString(accountId))
      .setTokenId(TokenId.fromString(tokenId));

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString()
    });
  } catch (error) {
    console.error('Error unfreezing account:', error);
    res.status(500).json({ error: error.message });
  }
});

// Wipe account
router.post('/wipe', async (req, res) => {
  try {
    const { accountId, tokenId, amount } = req.body;
    const client = getHederaClient();

    const transaction = new TokenWipeTransaction()
      .setAccountId(AccountId.fromString(accountId))
      .setTokenId(TokenId.fromString(tokenId))
      .setAmount(amount);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString()
    });
  } catch (error) {
    console.error('Error wiping account:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;