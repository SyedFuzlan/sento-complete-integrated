const express = require('express');
const { 
  ContractCreateTransaction, 
  ContractCallQuery,
  ContractInfoQuery,
  ContractId,
  Hbar
} = require('@hashgraph/sdk');
const { getHederaClient } = require('../config/hedera');

const router = express.Router();

// Deploy a smart contract
router.post('/deploy-contract', async (req, res) => {
  try {
    const { bytecode, gas } = req.body;
    const client = getHederaClient();

    const transaction = new ContractCreateTransaction()
      .setBytecode(bytecode)
      .setGas(gas)
      .setConstructorParameters();

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);
    const contractId = receipt.contractId;

    res.json({
      success: true,
      contractId: contractId.toString(),
      transactionId: txResponse.transactionId.toString(),
      gas: gas
    });
  } catch (error) {
    console.error('Error deploying contract:', error);
    res.status(500).json({ error: error.message });
  }
});

// Call a smart contract function
router.post('/call-contract', async (req, res) => {
  try {
    const { contractId, functionName, parameters, gas } = req.body;
    const client = getHederaClient();

    const transaction = new ContractCallQuery()
      .setContractId(ContractId.fromString(contractId))
      .setGas(gas)
      .setFunction(functionName, parameters);

    const result = await transaction.execute(client);

    res.json({
      success: true,
      result: result.toString(),
      contractId: contractId,
      functionName: functionName
    });
  } catch (error) {
    console.error('Error calling contract:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get contract information
router.get('/contract/:contractId', async (req, res) => {
  try {
    const { contractId } = req.params;
    const client = getHederaClient();

    const query = new ContractInfoQuery()
      .setContractId(ContractId.fromString(contractId));

    const info = await query.execute(client);

    res.json({
      success: true,
      contractId: info.contractId.toString(),
      accountId: info.accountId.toString(),
      adminKey: info.adminKey ? info.adminKey.toString() : null,
      storage: info.storage.toString(),
      contractMemo: info.contractMemo
    });
  } catch (error) {
    console.error('Error getting contract info:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;