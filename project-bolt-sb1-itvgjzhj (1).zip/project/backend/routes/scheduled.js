const express = require('express');
const { 
  ScheduleCreateTransaction, 
  ScheduleSignTransaction,
  ScheduleDeleteTransaction,
  ScheduleInfoQuery,
  ScheduleId,
  AccountId
} = require('@hashgraph/sdk');
const { getHederaClient } = require('../config/hedera');

const router = express.Router();

// Create a scheduled transaction
router.post('/create', async (req, res) => {
  try {
    const { payerAccountId, transactionBody, memo } = req.body;
    const client = getHederaClient();

    const transaction = new ScheduleCreateTransaction()
      .setPayerAccountId(AccountId.fromString(payerAccountId))
      .setScheduledTransaction(transactionBody);

    if (memo) {
      transaction.setScheduleMemo(memo);
    }

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);
    const scheduleId = receipt.scheduleId;

    res.json({
      success: true,
      scheduleId: scheduleId.toString(),
      transactionId: txResponse.transactionId.toString(),
      payerAccountId: payerAccountId,
      memo: memo || null
    });
  } catch (error) {
    console.error('Error creating scheduled transaction:', error);
    res.status(500).json({ error: error.message });
  }
});

// Sign a scheduled transaction
router.post('/sign', async (req, res) => {
  try {
    const { scheduleId, signature } = req.body;
    const client = getHederaClient();

    const transaction = new ScheduleSignTransaction()
      .setScheduleId(ScheduleId.fromString(scheduleId));

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString(),
      scheduleId: scheduleId
    });
  } catch (error) {
    console.error('Error signing scheduled transaction:', error);
    res.status(500).json({ error: error.message });
  }
});

// Execute a scheduled transaction (this happens automatically when enough signatures are collected)
router.post('/execute', async (req, res) => {
  try {
    const { scheduleId } = req.body;
    
    // In Hedera, scheduled transactions execute automatically when enough signatures are collected
    // This endpoint is for demonstration purposes
    res.json({
      success: true,
      message: 'Scheduled transactions execute automatically when enough signatures are collected',
      scheduleId: scheduleId
    });
  } catch (error) {
    console.error('Error executing scheduled transaction:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get scheduled transaction information
router.get('/:scheduleId', async (req, res) => {
  try {
    const { scheduleId } = req.params;
    const client = getHederaClient();

    const query = new ScheduleInfoQuery()
      .setScheduleId(ScheduleId.fromString(scheduleId));

    const info = await query.execute(client);

    res.json({
      success: true,
      scheduleId: info.scheduleId.toString(),
      payerAccountId: info.payerAccountId.toString(),
      scheduleMemo: info.scheduleMemo,
      adminKey: info.adminKey ? info.adminKey.toString() : null,
      executed: info.executed,
      deleted: info.deleted
    });
  } catch (error) {
    console.error('Error getting scheduled transaction info:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;