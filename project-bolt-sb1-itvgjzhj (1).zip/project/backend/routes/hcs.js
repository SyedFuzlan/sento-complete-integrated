const express = require('express');
const { 
  TopicCreateTransaction, 
  TopicMessageSubmitTransaction,
  TopicInfoQuery,
  TopicId
} = require('@hashgraph/sdk');
const { getHederaClient } = require('../config/hedera');

const router = express.Router();

// Create a new topic
router.post('/create-topic', async (req, res) => {
  try {
    const { memo, adminKey } = req.body;
    const client = getHederaClient();

    let transaction = new TopicCreateTransaction()
      .setTopicMemo(memo);

    if (adminKey) {
      transaction = transaction.setAdminKey(adminKey);
    }

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);
    const topicId = receipt.topicId;

    res.json({
      success: true,
      topicId: topicId.toString(),
      transactionId: txResponse.transactionId.toString(),
      memo: memo
    });
  } catch (error) {
    console.error('Error creating topic:', error);
    res.status(500).json({ error: error.message });
  }
});

// Submit a message to a topic
router.post('/submit-message', async (req, res) => {
  try {
    const { topicId, message } = req.body;
    const client = getHederaClient();

    const transaction = new TopicMessageSubmitTransaction()
      .setTopicId(TopicId.fromString(topicId))
      .setMessage(message);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString()
    });
  } catch (error) {
    console.error('Error submitting message:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get topic information
router.get('/topic/:topicId', async (req, res) => {
  try {
    const { topicId } = req.params;
    const client = getHederaClient();

    const query = new TopicInfoQuery()
      .setTopicId(TopicId.fromString(topicId));

    const info = await query.execute(client);

    res.json({
      success: true,
      topicId: info.topicId.toString(),
      memo: info.topicMemo,
      submitKey: info.submitKey ? info.submitKey.toString() : null,
      adminKey: info.adminKey ? info.adminKey.toString() : null
    });
  } catch (error) {
    console.error('Error getting topic info:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get messages from a topic (mock implementation)
router.get('/messages/:topicId', async (req, res) => {
  try {
    const { topicId } = req.params;
    
    // In a real implementation, you would use the Mirror Node API
    // to retrieve messages from the topic
    res.json({
      success: true,
      messages: [
        {
          message: "Hello from Hedera!",
          timestamp: new Date().toISOString(),
          sequenceNumber: 1
        }
      ]
    });
  } catch (error) {
    console.error('Error getting messages:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;