const express = require('express');
const { 
  TokenCreateTransaction, 
  TokenMintTransaction,
  TransferTransaction,
  TokenId,
  AccountId,
  TokenInfoQuery,
  TokenType,
  TokenSupplyType
} = require('@hashgraph/sdk');
const { getHederaClient } = require('../config/hedera');

const router = express.Router();

// Create NFT collection
router.post('/create-nft', async (req, res) => {
  try {
    const { name, symbol, metadata } = req.body;
    const client = getHederaClient();

    const transaction = new TokenCreateTransaction()
      .setTokenName(name)
      .setTokenSymbol(symbol)
      .setTokenType(TokenType.NonFungibleUnique)
      .setSupplyType(TokenSupplyType.Finite)
      .setMaxSupply(10000)
      .setTreasuryAccountId(client.operatorAccountId)
      .setSupplyKey(client.operatorPublicKey)
      .setAdminKey(client.operatorPublicKey);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);
    const tokenId = receipt.tokenId;

    res.json({
      success: true,
      tokenId: tokenId.toString(),
      transactionId: txResponse.transactionId.toString(),
      name,
      symbol
    });
  } catch (error) {
    console.error('Error creating NFT:', error);
    res.status(500).json({ error: error.message });
  }
});

// Mint NFT
router.post('/mint-nft', async (req, res) => {
  try {
    const { tokenId, metadata } = req.body;
    const client = getHederaClient();

    const transaction = new TokenMintTransaction()
      .setTokenId(TokenId.fromString(tokenId))
      .setMetadata([Buffer.from(metadata)]);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString(),
      serialNumber: receipt.serials[0].toString()
    });
  } catch (error) {
    console.error('Error minting NFT:', error);
    res.status(500).json({ error: error.message });
  }
});

// Transfer NFT
router.post('/transfer-nft', async (req, res) => {
  try {
    const { tokenId, serialNumber, fromAccountId, toAccountId } = req.body;
    const client = getHederaClient();

    const transaction = new TransferTransaction()
      .addNftTransfer(
        TokenId.fromString(tokenId),
        parseInt(serialNumber),
        AccountId.fromString(fromAccountId),
        AccountId.fromString(toAccountId)
      );

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString()
    });
  } catch (error) {
    console.error('Error transferring NFT:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get NFT information
router.get('/:tokenId/:serialNumber', async (req, res) => {
  try {
    const { tokenId, serialNumber } = req.params;
    const client = getHederaClient();

    const query = new TokenInfoQuery()
      .setTokenId(TokenId.fromString(tokenId));

    const info = await query.execute(client);

    // In a real implementation, you would use the Mirror Node API
    // to get NFT metadata and ownership information
    res.json({
      success: true,
      tokenId: info.tokenId.toString(),
      serialNumber: serialNumber,
      name: info.name,
      symbol: info.symbol,
      metadata: "Sample NFT metadata",
      accountId: info.treasury.toString()
    });
  } catch (error) {
    console.error('Error getting NFT info:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;