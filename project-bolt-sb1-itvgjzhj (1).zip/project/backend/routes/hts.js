const express = require('express');
const { 
  TokenCreateTransaction, 
  TokenMintTransaction,
  TokenBurnTransaction,
  TransferTransaction,
  TokenId,
  AccountId,
  TokenInfoQuery,
  Hbar
} = require('@hashgraph/sdk');
const { getHederaClient } = require('../config/hedera');

const router = express.Router();

// Create a new token
router.post('/create-token', async (req, res) => {
  try {
    const { name, symbol, decimals, initialSupply } = req.body;
    const client = getHederaClient();

    const transaction = new TokenCreateTransaction()
      .setTokenName(name)
      .setTokenSymbol(symbol)
      .setDecimals(decimals)
      .setInitialSupply(initialSupply)
      .setTreasuryAccountId(client.operatorAccountId)
      .setSupplyKey(client.operatorPublicKey)
      .setAdminKey(client.operatorPublicKey);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);
    const tokenId = receipt.tokenId;

    res.json({
      success: true,
      tokenId: tokenId.toString(),
      transactionId: txResponse.transactionId.toString(),
      name,
      symbol,
      decimals,
      initialSupply
    });
  } catch (error) {
    console.error('Error creating token:', error);
    res.status(500).json({ error: error.message });
  }
});

// Mint tokens
router.post('/mint-token', async (req, res) => {
  try {
    const { tokenId, amount } = req.body;
    const client = getHederaClient();

    const transaction = new TokenMintTransaction()
      .setTokenId(TokenId.fromString(tokenId))
      .setAmount(amount);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString(),
      newTotalSupply: receipt.totalSupply.toString()
    });
  } catch (error) {
    console.error('Error minting token:', error);
    res.status(500).json({ error: error.message });
  }
});

// Burn tokens
router.post('/burn-token', async (req, res) => {
  try {
    const { tokenId, amount } = req.body;
    const client = getHederaClient();

    const transaction = new TokenBurnTransaction()
      .setTokenId(TokenId.fromString(tokenId))
      .setAmount(amount);

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString(),
      newTotalSupply: receipt.totalSupply.toString()
    });
  } catch (error) {
    console.error('Error burning token:', error);
    res.status(500).json({ error: error.message });
  }
});

// Transfer tokens
router.post('/transfer-token', async (req, res) => {
  try {
    const { tokenId, fromAccountId, toAccountId, amount } = req.body;
    const client = getHederaClient();

    const transaction = new TransferTransaction()
      .addTokenTransfer(
        TokenId.fromString(tokenId),
        AccountId.fromString(fromAccountId),
        -amount
      )
      .addTokenTransfer(
        TokenId.fromString(tokenId),
        AccountId.fromString(toAccountId),
        amount
      );

    const txResponse = await transaction.execute(client);
    const receipt = await txResponse.getReceipt(client);

    res.json({
      success: true,
      transactionId: txResponse.transactionId.toString(),
      status: receipt.status.toString()
    });
  } catch (error) {
    console.error('Error transferring token:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get token information
router.get('/token/:tokenId', async (req, res) => {
  try {
    const { tokenId } = req.params;
    const client = getHederaClient();

    const query = new TokenInfoQuery()
      .setTokenId(TokenId.fromString(tokenId));

    const info = await query.execute(client);

    res.json({
      success: true,
      tokenId: info.tokenId.toString(),
      name: info.name,
      symbol: info.symbol,
      decimals: info.decimals,
      totalSupply: info.totalSupply.toString(),
      treasury: info.treasury.toString()
    });
  } catch (error) {
    console.error('Error getting token info:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;