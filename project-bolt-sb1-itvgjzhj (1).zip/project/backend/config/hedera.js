const { Client, PrivateKey } = require('@hashgraph/sdk');

// Initialize Hedera client
function getHederaClient() {
  const network = process.env.HEDERA_NETWORK || 'testnet';
  const accountId = process.env.HEDERA_ACCOUNT_ID;
  const privateKey = process.env.HEDERA_PRIVATE_KEY;

  if (!accountId || !privateKey) {
    throw new Error('Please set HEDERA_ACCOUNT_ID and HEDERA_PRIVATE_KEY in .env file');
  }

  let client;
  
  if (network === 'testnet') {
    client = Client.forTestnet();
  } else if (network === 'mainnet') {
    client = Client.forMainnet();
  } else {
    throw new Error('Invalid HEDERA_NETWORK. Use "testnet" or "mainnet"');
  }

  const key = PrivateKey.fromString(privateKey);
  client.setOperator(accountId, key);

  return client;
}

module.exports = { getHederaClient };