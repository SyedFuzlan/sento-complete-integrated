const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Import route modules
const hcsRoutes = require('./routes/hcs');
const htsRoutes = require('./routes/hts');
const hscsRoutes = require('./routes/hscs');
const nftRoutes = require('./routes/nft');
const accountRoutes = require('./routes/account');
const scheduledRoutes = require('./routes/scheduled');

// Use routes
app.use('/api/hcs', hcsRoutes);
app.use('/api/hts', htsRoutes);
app.use('/api/hscs', hscsRoutes);
app.use('/api/nft', nftRoutes);
app.use('/api/account', accountRoutes);
app.use('/api/scheduled', scheduledRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Hedera DApp Backend is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});